package com.capgemini.bo;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import com.capgemini.exception.AccountOpeningAmountInsufficientException;
import com.capgemini.exception.InsufficientBalanceException;
import com.capgemini.exception.InvalidAccountNumberException;
import com.capgemini.model.Account;
import com.capgemini.model.Address;
import com.capgemini.model.Customer;
import com.capgemini.model.Transaction;

public class ICICIBank {
  List<Account> accounts=new LinkedList<Account>();
  static int count=1000;
  int transactionCount=100;
 
  public String createAccount(int amount,String name,String city,int pincode) throws AccountOpeningAmountInsufficientException{
	  
		  if(amount>=500){
			  String accountNumber="ICICI"+count;
			  Address address=new Address(city, pincode);
			  Customer customer=new Customer(name, address);
			  Account account=new Account(accountNumber, amount,customer);
		     accounts.add(account);
		     count++;
		     return "Account created successfully";
		  }
		  
		  throw new AccountOpeningAmountInsufficientException();
	  }
  
  
  private Account searchAccount(String accountNumber) throws InvalidAccountNumberException{
	  for(Account account:accounts){
	     if(account.getAccountNumber().equals(accountNumber)){
		    return account;
	     }
	  }
	throw new InvalidAccountNumberException();
	  
  }
  public int withdrawAmount(String accountNumber,int amount) throws InvalidAccountNumberException, InsufficientBalanceException{
	  Account account = searchAccount(accountNumber);
		
		if((account.getAmount()-amount)>=0)
		{
			account.setAmount(account.getAmount()-amount);
			return account.getAmount();
		}
		
		throw new InsufficientBalanceException();
	
  }
  public int depositAmount(String accountNumber,int amount) throws InvalidAccountNumberException{
	  Account account = searchAccount(accountNumber);
	  account.setAmount(account.getAmount()+amount);
	  Date date=new Date();
	  int id=transactionCount++;
	  Transaction transaction=new Transaction(id,"deposit", date, amount);
	  Transaction[] transc=new Transaction[4];
	  
	  return account.getAmount();	
  }
  public int[] fundTransfer(String senderAccountNumber,String recieverAccountNumber,int amount) throws InvalidAccountNumberException, InsufficientBalanceException{
	  Account senderAccount = searchAccount(senderAccountNumber); 
	  Account recieverAccount= searchAccount(recieverAccountNumber);
	  int[] balance=new int[2];
	  if(senderAccount.getAmount()>amount){
		  senderAccount.setAmount(senderAccount.getAmount()-amount);
		  recieverAccount.setAmount(recieverAccount.getAmount()+amount);
		  balance[0]=senderAccount.getAmount();
		  balance[1]=recieverAccount.getAmount(); 
		 return balance;
	  }
	  throw new InsufficientBalanceException();
	  
  }
  
}
