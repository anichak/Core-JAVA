package com.capgemini.model;

import java.util.Date;

public class Transaction {
  private int id;
  private String type;
  private Date date;
  private int amount;
  
public Transaction() {
	super();
}

public Transaction(int id, String type, Date date, int amount) {
	super();
	this.id = id;
	this.type = type;
	this.date = date;
	this.amount = amount;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

public Date getDate() {
	return date;
}

public void setDate(Date date) {
	this.date = date;
}

public int getAmount() {
	return amount;
}

public void setAmount(int amount) {
	this.amount = amount;
}

@Override
public String toString() {
	return "Transaction [id=" + id + ", type=" + type + ", date=" + date + ", amount=" + amount + "]";
}
  
}
