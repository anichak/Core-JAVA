package com.capgemini.exception;

public class AccountOpeningAmountInsufficientException extends Exception {

}
