package com.capgemini.client;

import com.capgemini.bo.ICICIBank;
import com.capgemini.exception.AccountOpeningAmountInsufficientException;
import com.capgemini.exception.InsufficientBalanceException;
import com.capgemini.exception.InvalidAccountNumberException;

public class ClientCode {

	public static void main(String[] args) {
		ICICIBank ib=new ICICIBank();
		try {
			    System.out.println(ib.createAccount(500,"Anindita","Jamshedpur",831009));
			    System.out.println(ib.createAccount(1000,"Antara","Kolkata",700100));
				System.out.println("Balance= " +ib.depositAmount("ICICI1000", 700));
				System.out.println("Balance= " +ib.withdrawAmount("ICICI1001",200));
				int[] balance=ib.fundTransfer("ICICI1000","ICICI1001",200);
				System.out.println("Sender Balance= " +balance[0]);
				System.out.println("Reciever Balance= " +balance[1]);
			} catch (InvalidAccountNumberException e) {
				System.out.println("Account number is invalid");
			} catch (InsufficientBalanceException e) {
				System.out.println("Insufficient Balance");
			} catch (AccountOpeningAmountInsufficientException e) {
				System.out.println("Account Opening amount should be atleast 500");
			}
		

	}

}
