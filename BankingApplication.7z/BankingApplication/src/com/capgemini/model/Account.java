package com.capgemini.model;

public class Account {
   private String accountNumber;
   private int amount;
   private Customer customer;
   private Transaction[] transaction;
   
public Account() {
	super();
}

public Account(String accountNumber, int amount, Customer customer) {
	super();
	this.accountNumber = accountNumber;
	this.amount = amount;
	this.customer = customer;
}

public String getAccountNumber() {
	return accountNumber;
}

public void setAccountNumber(String accountNumber) {
	this.accountNumber = accountNumber;
}

public int getAmount() {
	return amount;
}

public void setAmount(int amount) {
	this.amount = amount;
}

public Customer getCustomer() {
	return customer;
}

public void setCustomer(Customer customer) {
	this.customer = customer;
}

public Transaction[] getTransaction() {
	return transaction;
}

public void setTransaction(Transaction[] transaction) {
	this.transaction = transaction;
}

@Override
public String toString() {
	return "Account [accountNumber=" + accountNumber + ", amount=" + amount + ", customer=" + customer + "]";
}


   
   
}
